export const sum = (numbers) => numbers.reduce((a, b) => a + b, 0);
export const average = (numbers) => sum(numbers) / numbers.length;
